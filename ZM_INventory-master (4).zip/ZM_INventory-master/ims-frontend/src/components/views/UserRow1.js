/*
    SAHAN

 */

import React from "react";
import axio from "axios";
import UserUpdateForm from '../forms/UserUpdateForm';
import reduxDialog from 'redux-reactstrap-modal';
//import { confirmAlert } from 'react-confirm-alert'; // Import
//import 'react-confirm-alert/src/react-confirm-alert.css'; // Import css

class UserRow extends React.Component{

    constructor(props){
        super(props);
        this.deleteUser = this.deleteUser.bind(this);
        this.state={
            activeStatus: false,
            userData:''
        }
    }

    componentWillMount() {
        axio.get('http://localhost:5000/api/users')
            .then(res => {
                this.setState({
                    users: res.data
                })
                console.log(res.data)
            })
            .catch(res => {
                console.log(res.error)
            });
    }


    deleteUser(){

        var userPreference;

        axio.delete('http://localhost:5000/api/users/' + this.props.obj.id)
            .then(response => {

                window.confirm("Do you really want to delete?");
            })
            .catch(error => {
                console.log(error.response)

            });
    }



    render() {
        return(
            <tr className="positive">
                <td>{this.props.obj.id}</td>
                <td>{this.props.obj.name}</td>
                <td>{this.props.obj.department}</td>
            </tr>
        )
    }
}
export default UserRow;




//onClick={()=>this.props.oprnDialod('abs',{data:this.props.obj})}