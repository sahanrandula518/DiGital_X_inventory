import * as createHistory from "history";
const history = createHistory.createBrowserHistory();

export default history;